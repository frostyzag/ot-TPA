VOCATION = {
	ID = {
		NONE = 0,
		SORCERER = 1,
		DRUID = 2,
		PALADIN = 3,
		KNIGHT = 4,
		MASTER_SORCERER = 5,
		ELDER_DRUID = 6,
		ROYAL_PALADIN = 7,
		ELITE_KNIGHT = 8,
		HUMAN = 110,
		LEGENDARY_HUMAN = 111,
		GHOUL = 112,
		UNDEAD = 113,
		MINK = 114,
		MINKV2 = 120,
		FISHMAN = 121,
		SHARKMAN = 122,
		SKYPIEA = 123,
		SKYPIEAV2 = 124,
		GIANT = 130,
		COLOSSUS = 131,
	},
	CLIENT_ID = {
		NONE = 0,
		KNIGHT = 1,
		PALADIN = 2,
		SORCERER = 3,
		DRUID = 4,
		ELITE_KNIGHT = 11,
		ROYAL_PALADIN = 12,
		MASTER_SORCERER = 13,
		ELDER_DRUID = 14,
		HUMAN = 110,
		LEGENDARY_HUMAN = 111,
		GHOUL = 112,
		UNDEAD = 113,
		MINK = 114,
		MINKV2 = 120,
		FISHMAN = 121,
		SHARKMAN = 122,
		SKYPIEA = 123,
		SKYPIEAV2 = 124,
		GIANT = 130,
		COLOSSUS = 131,
	},
	BASE_ID = {
		NONE = 0,
		SORCERER = 1,
		DRUID = 2,
		PALADIN = 3,
		KNIGHT = 4,
		HUMAN = 110,
		GHOUL = 112,
		MINK = 114,
		FISHMAN = 121,
		SKYPIEA = 123,
		GIANT = 130,
	},
}

function Vocation.getBase(self)
	local base = self
	while base:getDemotion() do
		base = base:getDemotion()
	end
	return base
end
