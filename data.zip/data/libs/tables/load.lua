-- Load tables functions
dofile(CORE_DIRECTORY .. "/libs/tables/doors.lua")
dofile(CORE_DIRECTORY .. "/libs/tables/windows.lua")
