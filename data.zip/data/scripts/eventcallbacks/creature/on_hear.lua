local callback = EventCallback("CreatureOnHearBaseEvent")

function callback.creatureOnHear(creature, speaker, words, type) end

callback:register()
