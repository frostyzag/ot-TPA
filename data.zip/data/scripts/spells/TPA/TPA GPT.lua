local combat = Combat()
combat:setParameter(COMBAT_PARAM_TYPE, COMBAT_HAKIDAMAGE)  -- Definindo o tipo de dano como Haki
combat:setParameter(COMBAT_PARAM_EFFECT, CONST_ME_MAGIC_BLUE)  -- Efeito visual correspondente
combat:setParameter(COMBAT_PARAM_DISTANCEEFFECT, CONST_ANI_BLUEENERGY)  -- Efeito de distância
combat:setParameter(COMBAT_PARAM_BLOCKARMOR, 1)  -- Definindo que o dano pode ser bloqueado por armaduras

function onGetFormulaValues(player, level, skill, factor)
    local fist = player:getSkillLevel(SKILL_FIST)
    local skillTotal = fist
    local levelTotal = player:getLevel() / 10
    local minDmg = -(((skillTotal / 1.4) * (levelTotal / 2))) * 1.1  -- Fórmula para dano mínimo
    local maxDmg = -((skillTotal / 1.2) * (levelTotal / 2.1)) * 1.2  -- Fórmula para dano máximo
    
    -- Verifica se o dano mínimo ou máximo é negativo e os corrige
    minDmg = math.max(minDmg, 0)
    maxDmg = math.max(maxDmg, 0)
    
    return minDmg, maxDmg  -- Retorna o valor do dano calculado
end

combat:setCallback(CALLBACK_PARAM_SKILLFISTVALUE, "onGetFormulaValues")

local spell = Spell("instant")  -- Tipo de magia: instantânea

function spell.onCastSpell(creature, var)
    return combat:execute(creature, var)  -- Executa o combate ao lançar a magia
end

spell:group("attack")
spell:id(149)  -- ID único da magia
spell:name("haki punch")  -- Nome da magia
spell:words("haki punch")  -- Comando utilizado pelo jogador
spell:castSound(SOUND_EFFECT_TYPE_SPELL_OR_RUNE)  -- Som do efeito da magia
spell:impactSound(SOUND_EFFECT_TYPE_SPELL_HIT)  -- Som de impacto da magia
spell:level(10)  -- Nível necessário para usar a magia
spell:mana(50)  -- Custo de mana
spell:isPremium(false)  -- Pode ser usado por todos os jogadores
spell:range(1)  -- A magia tem alcance de 1
spell:needCasterTargetOrDirection(true)  -- Necessita de alvo ou direção
spell:blockWalls(true)  -- Bloqueia o uso de paredes
spell:cooldown(3 * 1000)  -- Tempo de recarga entre lançamentos
spell:groupCooldown(1 * 1000)  -- Tempo de recarga no grupo
spell:needLearn(false)  -- Não precisa ser aprendido, pode ser utilizado diretamente
spell:vocation(110, 111, 112, 113, 114, 120, 121, 122, 123, 124, 130, 131)  -- Vocações que podem usar a magia
spell:register()  -- Registra a magia
