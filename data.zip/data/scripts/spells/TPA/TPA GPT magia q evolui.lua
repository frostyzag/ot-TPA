local combat1 = Combat()
combat1:setParameter(COMBAT_PARAM_TYPE, COMBAT_ICEDAMAGE)
combat1:setParameter(COMBAT_PARAM_EFFECT, CONST_ME_ICESTORM)
combat1:setParameter(COMBAT_PARAM_DISTANCEEFFECT, CONST_ANI_SNOWBALL)
combat1:setParameter(COMBAT_PARAM_BLOCKARMOR, 1)
combat1:setArea(createCombatArea({{1}})) -- Área de 1 sqm

local combat2 = Combat()
combat2:setParameter(COMBAT_PARAM_TYPE, COMBAT_ICEDAMAGE)
combat2:setParameter(COMBAT_PARAM_EFFECT, CONST_ME_ICESTORM)
combat2:setParameter(COMBAT_PARAM_DISTANCEEFFECT, CONST_ANI_SNOWBALL)
combat2:setParameter(COMBAT_PARAM_BLOCKARMOR, 1)
combat2:setArea(createCombatArea({
    {0, 1, 0},
    {1, 1, 1},
    {0, 1, 0}
})) -- Área de 2 sqm

local combat3 = Combat()
combat3:setParameter(COMBAT_PARAM_TYPE, COMBAT_ICEDAMAGE)
combat3:setParameter(COMBAT_PARAM_EFFECT, CONST_ME_ICESTORM)
combat3:setParameter(COMBAT_PARAM_DISTANCEEFFECT, CONST_ANI_SNOWBALL)
combat3:setParameter(COMBAT_PARAM_BLOCKARMOR, 1)
combat3:setArea(createCombatArea({
    {0, 0, 1, 0, 0},
    {0, 1, 1, 1, 0},
    {1, 1, 1, 1, 1},
    {0, 1, 1, 1, 0},
    {0, 0, 1, 0, 0}
})) -- Área de 3 sqm

function onGetFormulaValues(player, level, skill, factor)
    local fist = player:getSkillLevel(SKILL_FIST)
    local skillTotal = fist
    local levelTotal = player:getLevel() / 10
    return -(((skillTotal / 1.4) * (levelTotal / 2))) * 1.1, -((skillTotal / 1.2) * (levelTotal / 2.1)) * 1.2
end

combat1:setCallback(CALLBACK_PARAM_SKILLFISTVALUE, "onGetFormulaValues")
combat2:setCallback(CALLBACK_PARAM_SKILLFISTVALUE, "onGetFormulaValues")
combat3:setCallback(CALLBACK_PARAM_SKILLFISTVALUE, "onGetFormulaValues")

local spell = Spell("instant")

function spell.onCastSpell(creature, var)
    local player = creature:getPlayer()
    if not player then
        return false
    end

    local currentUses = player:getStorageValue(1000)
    if currentUses < 0 then
        currentUses = 0
    end

    currentUses = currentUses + 1
    player:setStorageValue(1000, currentUses)

    if currentUses < 10 then
        return combat1:execute(player, var)
    elseif currentUses < 20 then
        return combat2:execute(player, var)
    else
        return combat3:execute(player, var)
    end
end

spell:group("attack")
spell:id(151)
spell:name("Ice Evolution")
spell:words("ice evo")
spell:castSound(SOUND_EFFECT_TYPE_SPELL_OR_RUNE)
spell:impactSound(SOUND_EFFECT_TYPE_SPELL_ICESTORM)
spell:level(1)
spell:mana(30)
spell:isPremium(false)
spell:range(1)
spell:needCasterTargetOrDirection(true)
spell:blockWalls(true)
spell:cooldown(3 * 1000)
spell:groupCooldown(2 * 1000)
spell:needLearn(false)
spell:vocation(110, 111, 112, 113, 114, 120, 121, 122, 123, 124, 130, 131)
spell:register()
