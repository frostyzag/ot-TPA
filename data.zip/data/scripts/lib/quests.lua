-- We need to register the variables beforehand to avoid accessing null values.
if RegisterSoulWarBossesLevers then
	RegisterSoulWarBossesLevers()
end
